export const environment = {
  production: true,
  // baseApi: 'http://202.129.196.133/boarding-system'
  // baseApi: 'http://202.129.196.133/onboarding-api'
  
  baseApi: 'http://106.51.50.95:5428/onboard-api'
  // baseApi: 'http://cgvakstage.com:8085/onboard-api'
};
